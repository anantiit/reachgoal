package lld.autosuggest;

public class Word {
	String word;
	Integer frequency;
}
