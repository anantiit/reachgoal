package lld.autosuggest;

public class Constants {
	public static final int TTL_SECS = 3 * 3600; // 3 hours
	public static final int AUTO_SUGEST_LIMIT = 5; // 3 hours
}
