package lld.autosuggest.autosuggest;

public class AutoSuggestRepository {

	public void getAutoSuggestionsFromDB(String prefix, int autoSugestLimit) {
		// TODO Auto-generated method stub

	}

}
