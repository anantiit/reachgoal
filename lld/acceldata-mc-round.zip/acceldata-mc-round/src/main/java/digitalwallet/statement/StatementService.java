package digitalwallet.statement;

public class StatementService {

}
