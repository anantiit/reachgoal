package digitalwallet.user;

import lombok.AllArgsConstructor;

@AllArgsConstructor
public class User {
	int id;
	String name;
	String emailId;
	String phoneNum;
	String walletId;
}
