package digitalwallet.exceptions;

public class BalanceInsufficientException extends RuntimeException {

}
