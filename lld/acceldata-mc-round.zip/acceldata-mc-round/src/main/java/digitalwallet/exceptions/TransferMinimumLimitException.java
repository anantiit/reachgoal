package digitalwallet.exceptions;

public class TransferMinimumLimitException extends RuntimeException {

}
