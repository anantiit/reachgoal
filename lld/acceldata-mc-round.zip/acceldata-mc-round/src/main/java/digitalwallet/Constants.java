package digitalwallet;

public class Constants {
	public static double MINIMUM_TRANSFER_AMOUNT = 0.0001;
	public static double MINIMUM_BALANCE_AMOUNT = 0.0;
}
