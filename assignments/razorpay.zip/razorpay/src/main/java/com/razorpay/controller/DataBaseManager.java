package com.razorpay.controller;

public class DataBaseManager {
public static void main(String args[]) {
	DataBase db = new Data
}
}
