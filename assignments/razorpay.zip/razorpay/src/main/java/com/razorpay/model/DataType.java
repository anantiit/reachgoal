package com.razorpay.model;

public enum DataType {
	String, Integer;
}
