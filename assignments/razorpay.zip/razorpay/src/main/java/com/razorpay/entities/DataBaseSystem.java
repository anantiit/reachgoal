package com.razorpay.entities;

import java.util.Set;

public class DataBaseSystem {
	Set<DataBase> dbs;
}
