package com.razorpay.entities;

import java.util.Set;

public class DataBase {
	Set<Table> tables;
}
