package com.razorpay.entities;

public class Column<T> {
	String name;
	T value;

	public Column(String name, T value) {
		super();
		this.name = name;
		this.value = value;
	}

}
