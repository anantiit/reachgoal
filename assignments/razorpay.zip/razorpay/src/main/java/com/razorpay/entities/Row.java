package com.razorpay.entities;

import java.util.List;

public class Row {
	Map<String,
	List<Column<T>> columns;
}
