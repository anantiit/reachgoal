package com.razorpay.entities;

import java.util.Set;

public class DBSchema {
	Set<TableSchema> tableScehmas;
}
